package com.example.ap02_04.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ap02_04.R;
import com.example.ap02_04.entities.User;

import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends AppCompatActivity {

    EditText username;
    EditText password;
    Button loginButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);

        List<User> users = new ArrayList<>();

        users.add(new User("aaa@gmail.com", "12345678a", "Alice0", 0));
        users.add(new User("bbb@gmail.com", "12345678b", "Alice1", 1));
        users.add(new User("ccc@gmail.com", "12345678c", "Alice2", 2));
        users.add(new User("ddd@gmail.com", "12345678d", "Alice3", 3));


        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean connect = false;
                for (User user : users) {
                    if (username.getText().toString().equals(user.getUsername()) &&
                            password.getText().toString().equals(user.getPassword())) {
                        connect = true;
                    }
                }
                if (connect) {
                    Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(this, ChatsActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(LoginActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}