package com.example.ap02_04.viewmodels;

import androidx.lifecycle.ViewModel;

public class MessagesViewModel extends ViewModel {



    //get all messages by chat id


}
