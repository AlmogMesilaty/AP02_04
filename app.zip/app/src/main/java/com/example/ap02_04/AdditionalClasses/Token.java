package com.example.ap02_04.AdditionalClasses;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
public class Token {
    private String token;
    public Token(String token) {
        this.token = token;
    }

    public Token createToken(String username, String password) {
        // Generate the token
        String token = Jwts.builder()
                .setSubject(username)
                .signWith(SignatureAlgorithm.HS256, password)
                .compact();

        return new Token(token);

    }

    public boolean validateToken(String token) {
        try {
            // Verify the token is valid
            Claims claims = Jwts.parser().parseClaimsJwt(token).getBody();
            return true;
        } catch (JwtException e) {
            return false;
        }
    }

    public String getToken() {
        return token;
    }
}
