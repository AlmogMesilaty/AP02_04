package com.example.ap02_04.viewmodels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.example.ap02_04.entities.User;
import com.example.ap02_04.repositories.UserRepository;

import java.util.List;

public class UserViewModel extends ViewModel {

    private UserRepository mRepository;
    private LiveData<List<User>> users;

    public UserViewModel() {
        mRepository = new UserRepository();
        users = mRepository.getUsers;
    }

    public LiveData<List<User>> getUsers() {
        return users;
    }

    public User getUserByUserName(String username) {
        List<User> users = (List<User>) getUsers();
        if(users != null){
            for(User user : users) {
                if (user.getUsername() == username) {
                    return user;
                }
            }
        }
        return null;
    }


}
