package com.example.ap02_04.repositories;

public class UserRepository {


}
